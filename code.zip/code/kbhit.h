//
// Created by Aliez on 2018/7/7.
//

#ifndef INC_2048_KBHIT_H
#define INC_2048_KBHIT_H

void changemode(int);
int  kbhit();

#endif //INC_2048_KBHIT_H
